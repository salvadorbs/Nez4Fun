﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Nez;
using Nez.Sprites;

namespace $rootnamespace$
{
    class $safeitemname$ : Scene
    {
        public override void initialize()
        {

        }
    }
}
