﻿using System;
using Microsoft.Xna.Framework;
using Nez;
using Nez.Sprites;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace $rootnamespace$
{
    class $safeitemname$ : Entity
    {
				public $safeitemname$() : base("$safeitemname$")
				{ }

        public override void onAddedToScene()
        {
				    base.onAddedToScene();
        }
    }
}